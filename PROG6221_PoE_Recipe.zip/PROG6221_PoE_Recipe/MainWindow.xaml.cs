﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROG6221_PoE_Recipe
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //List from Recipe class
        private List<Recipe> recipes = new List<Recipe>();
        public MainWindow()
        {
            InitializeComponent();
        }

        //User can add unlimited recipes by clicking add button
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            //try catch for any error 
            try
            {
                //creating List for the values
                ListViewItem listViewItem = new ListViewItem();

                //Creating variables
                double ingNum, qty, calories;
                string ingName, unit, foodgroup,recipeName;


                
                //Linking the variables to the textboxes
                qty = Convert.ToDouble(txtQty.Text);
                calories = Convert.ToDouble(txtCalories.Text);

                recipeName = txtRecipeName.Text;
                ingName = txtIngName.Text;
                unit = txtUnit.Text;
                foodgroup = txtFD.Text;

               

                
                //Adding the variables to the ListBox
                    lstDisplay1.Items.Add("Recipe Name\n" + recipeName);
                    lstDisplay1.Items.Add("\nIngrient Name: " + ingName);
                    lstDisplay1.Items.Add("\nQuantity: " + qty);
                    lstDisplay1.Items.Add("\nUnit of Measurements: " + unit);
                    lstDisplay1.Items.Add("\nCalories: " + calories);
                    lstDisplay1.Items.Add("\nFood Group: "  + foodgroup);

                //Warning message for when calories exceed 300
                if (calories > 300)
                {
                    MessageBox.Show("WARNING: The total calories of the recipe exceed 300!");
                }
                

                txtQty.Clear();
                txtIngName.Clear();
                txtCalories.Clear();
                txtUnit.Clear(); 
                txtFD.Clear();  
                txtRecipeName.Clear();
               

            }
            catch {
                MessageBox.Show("Enter correct values or enter all fields");
            }

        }

        //Button that clears textbox
        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            lstDisplay1.Items.Clear();
            MessageBox.Show("Recipe has been cleared");
        }

        //Method to add items used for the steps and description
        public void AddItems(string item)
        {
            lstDisplay1.Items.Add(item);
        }

        //Button takes you to steps window
        private void btnSteps_Click(object sender, RoutedEventArgs e)
        {
            Steps scl = new Steps();
            scl.ShowDialog();
        }

        //Button that scales the quantity
        private void btnScale_Click(object sender, RoutedEventArgs e)
        {
            //Checking the radio buttons
            if (rdScale0_5.IsChecked == true)
            {
                double scaleMultiplier = 0.5;
                ScaleQuantity(scaleMultiplier);
            }
            else if (rdScale2.IsChecked == true)
            {
                // Option 2 is selected
                double scaleMultiplier = 2;
                ScaleQuantity(scaleMultiplier);
            }
            else if (rdScale3.IsChecked == true)
            {
                //Option 3 is selected
                double scaleMultiplier = 3;
                ScaleQuantity(scaleMultiplier);
            }
            else 
            {
                // No option is selected
                MessageBox.Show("Select a scaling amount");
            }

        }

        //Methid that deals with scaling the amount using radio button
        private void ScaleQuantity(double scaleMultiplier)
        {
            for (int i = 0; i < lstDisplay1.Items.Count; i++)
            {
                if (lstDisplay1.Items[i] is string)
                {
                    string text = lstDisplay1.Items[i] as string;
                    if (text.StartsWith("\nQuantity: "))
                    {
                        string qtyText = text.Substring("\nQuantity: ".Length);
                        if (double.TryParse(qtyText, out double qty))
                        {
                            double scaledQty = qty * scaleMultiplier;
                            text = "\nQuantity: " + scaledQty;
                            lstDisplay1.Items[i] = text;
                        }
                    }
                }
            }
        }

        //Button for filtering the menu
        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FilterWindow filterWindow = new FilterWindow();
                bool? result = filterWindow.ShowDialog();

                if (result == true)
                {
                    // Get the filter criteria from the FilterWindow
                    string filterIngredient = filterWindow.FilterIngredient;
                    string filterFoodGroup = filterWindow.FilterFoodGroup;
                    double filterCalories = filterWindow.FilterCalories;

                    lstDisplay1.Items.Clear();

                    foreach (var item in recipes)
                    {
                        string text = item.ToString();
                        bool shouldDisplay = true;

                        if (!string.IsNullOrEmpty(filterIngredient))
                        {
                            if (!text.Contains(filterIngredient))
                            {
                                shouldDisplay = false;
                            }
                        }

                        if (!string.IsNullOrEmpty(filterFoodGroup))
                        {
                            if (!text.Contains("\nFood Group: " + filterFoodGroup))
                            {
                                shouldDisplay = false;
                            }
                        }

                        if (filterCalories < double.MaxValue)
                        {
                            if (text.Contains("\nCalories: "))
                            {
                                string caloriesText = text.Substring(text.IndexOf("\nCalories: ") + "\nCalories: ".Length);
                                if (double.TryParse(caloriesText, out double calories))
                                {
                                    if (calories > filterCalories)
                                    {
                                        shouldDisplay = false;
                                    }
                                }
                            }
                        }

                        if (shouldDisplay)
                        {
                            lstDisplay1.Items.Add(item);
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Enter correct values");
            }
        }

    }
}
