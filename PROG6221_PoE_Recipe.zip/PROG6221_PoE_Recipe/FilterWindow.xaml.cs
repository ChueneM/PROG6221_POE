﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROG6221_PoE_Recipe
{
    /// <summary>
    /// Interaction logic for FilterWindow.xaml
    /// </summary>
    public partial class FilterWindow : Window
    {
        public string FilterIngredient { get; private set; }
        public string FilterFoodGroup { get; private set; }
        public double FilterCalories { get; private set; }

        public FilterWindow()
        {
            InitializeComponent();
        }

        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Get the filter criteria
                FilterIngredient = txtFilterIngredient.Text;
                FilterFoodGroup = cmbFilterFoodGroup.SelectedItem?.ToString();
                FilterCalories = string.IsNullOrEmpty(txtFilterCalories.Text) ? double.MaxValue : Convert.ToDouble(txtFilterCalories.Text);

                DialogResult = true;
            }
            catch
            {
                MessageBox.Show("Enter correct values");
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }


}
